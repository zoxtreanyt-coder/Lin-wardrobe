# Lin wardrobe — Glass Minimalista + Editorial de Moda

Proyecto Capacitor para compilar **solo un APK Android** mediante GitHub Actions. La app guarda prendas, fotos, etiquetas, outfits y copias de seguridad localmente en el dispositivo; no requiere cuenta ni nube.

## Estilos incluidos

- **Glass Minimalista**: paneles translúcidos, desenfoque sutil y tonos neutros.
- **Editorial de Moda**: tipografía editorial, colores cálidos, tarjetas más sobrias y presentación inspirada en revistas de moda.
- **Tema claro/oscuro** independiente del estilo visual.

Los botones `☾/☀` y `ED/GL` están separados. La elección de tema y estilo se guarda en el dispositivo.

## Crear el APK en GitHub

1. Crea un repositorio nuevo en GitHub.
2. Descomprime este ZIP y sube **el contenido** de la carpeta al repositorio (el archivo `README.md` debe quedar en la raíz).
3. Abre la pestaña **Actions** y habilita GitHub Actions si GitHub lo solicita.
4. El workflow **Build Lin wardrobe APK** se ejecuta automáticamente al subir cambios a `main` o `master`. También puedes ejecutarlo con **Run workflow**.
5. Cuando termine correctamente, abre la ejecución y descarga el artefacto **`lin-wardrobe-debug-apk`**.
6. Dentro del ZIP del artefacto encontrarás `app-debug.apk`, listo para instalar en Android 12 o posterior compatible.

El workflow solo compila y publica como artefacto el APK debug; no genera una web publicada ni sube el APK a una tienda.

## Importante sobre datos y firmas

- Antes de reemplazar una instalación anterior, exporta una copia desde la sección **Backup** y guárdala fuera del teléfono.
- El APK compilado por GitHub se firma como debug con una clave temporal de ese entorno. Si lo compilas en otra ejecución, puede tener otra firma. Android puede no permitir instalarlo encima de otra versión con una firma diferente; en ese caso desinstalar la app anterior puede borrar sus datos locales. Importa primero tu copia de seguridad.
- Para actualizaciones consistentes a largo plazo, habrá que configurar una clave de firma privada persistente en GitHub Secrets. No subas una clave privada al repositorio.

## Desarrollo local (opcional)

Requiere Node.js 20, Java 17 y Android SDK:

```bash
npm install
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

El HTML de la aplicación está en `www/index.html`. No cambies `appId` (`com.closetglass.app`) si quieres conservar el identificador de la aplicación.
